import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Fraunces"', 'Georgia', 'serif'],
        sans: ['"Inter Tight"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      colors: {
        ink: '#0F1115',
        paper: '#F6F3EC',
        rule: '#1F2329',
        muted: '#6B7079',
        // TfL-inspired mode palette — used sparingly as accent chips
        mode: {
          tube: '#DC241F',
          bus: '#E87722',
          rail: '#1D4A8A',
          elizabeth: '#6950A1',
          overground: '#EE7C0E',
          dlr: '#00A4A7',
          cycle: '#000000',
          walk: '#6B7079',
        },
      },
      boxShadow: {
        card: '0 1px 0 0 #1F2329',
      },
    },
  },
  plugins: [],
};

export default config;
