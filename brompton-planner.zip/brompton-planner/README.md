# Brompton London Journey Planner

A Brompton-aware route planner for London. Treats your folding bike as a bike when ridden and as luggage when folded, then scores routes accordingly.

## What's in this starter

- `/app/api/plan/route.ts` — the API endpoint that orchestrates TfL fetch, scoring, and response
- `/lib/tfl.ts` — TfL Unified API client
- `/lib/normalise.ts` — converts TfL journeys to internal legs with bike state
- `/lib/folding.ts` — detects fold/unfold transitions
- `/lib/scoring.ts` — the core scoring and ranking logic
- `/lib/explain.ts` — generates "why this / why not" text
- `/data/stations.json` — hand-curated awkward-station list (seed: 10 stations)

## What's not yet built

UI components. The backend is working and the API endpoint returns scored routes. Next steps:
1. `/app/page.tsx` — the main form
2. `/components/RouteCard.tsx` — result card with fold markers
3. `/components/LegStrip.tsx` — horizontal leg timeline

## Run locally

```bash
npm install
echo "TFL_APP_KEY=your_key_here" > .env.local
npm run dev
```

Get a TfL app key at https://api.tfl.gov.uk/ (free).

## Testing the API without UI

```bash
curl -X POST http://localhost:3000/api/plan \
  -H "Content-Type: application/json" \
  -d '{
    "from": "Paddington",
    "to": "Canary Wharf",
    "when": { "mode": "depart", "iso": "2026-04-17T08:30:00Z" },
    "weights": { "time": 0.25, "cost": 0.25, "hassle": 0.35, "carry": 0.15 },
    "maxCycleMinutesPerLeg": 20,
    "hasExtraLuggage": false,
    "stepFreeOnly": false
  }'
```

## Implementation plan (from spec)

1. [x] Scaffold + TfL connectivity
2. [x] Type the TfL response
3. [x] Leg normaliser
4. [x] Station metadata + fold-event computation
5. [x] Scoring
6. [ ] UI: form + results
7. [ ] UI: polish
8. [ ] Deploy to Vercel

## Trade-offs made

- **No database.** Station metadata is a JSON file in the repo. Revisit only when you need accounts.
- **No map.** Text-first. A map is the single biggest scope-creep risk; defer.
- **In-memory cache.** Fine for single-instance hobby deploy. Swap to Redis if you scale.
- **Hand-written TfL types.** Auto-generated from OpenAPI is verbose and gets in the way.
- **Template explanations, not LLM.** Predictable, fast, free, and honestly better for this use case.

## Known limitations to fix next

- `estimateFareFromLegs` is crude — revisit with current TfL pricing
- Peak detection uses server time, not journey time — fine for "depart now", wrong for "arrive by 6pm"
- Station metadata is seeded from memory; verify against TfL's step-free accessibility data
- No handling of Brompton-specific rules on buses (folded bike only) — currently implicit in bike state logic
