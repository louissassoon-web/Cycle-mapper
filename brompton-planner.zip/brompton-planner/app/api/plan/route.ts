// POST /api/plan
// Orchestrates: TfL fetch → normalise → score → explain → respond.

import { NextRequest, NextResponse } from 'next/server';
import { fetchAllCandidates } from '@/lib/tfl';
import { normaliseJourney } from '@/lib/normalise';
import { scoreRoutes } from '@/lib/scoring';
import { explain } from '@/lib/explain';
import type { PlanRequest, ScoredRoute } from '@/lib/types';

// Very simple in-memory cache. Good enough for single-instance deploys.
const cache = new Map<string, { at: number; routes: ScoredRoute[] }>();
const CACHE_TTL_MS = 60 * 1000;

function cacheKey(req: PlanRequest): string {
  return JSON.stringify(req);
}

export async function POST(request: NextRequest) {
  let body: PlanRequest;
  try {
    body = (await request.json()) as PlanRequest;
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  if (!body.from || !body.to) {
    return NextResponse.json({ error: 'from and to are required' }, { status: 400 });
  }

  const key = cacheKey(body);
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < CACHE_TTL_MS) {
    return NextResponse.json({ routes: hit.routes, cached: true });
  }

  try {
    const tflResponse = await fetchAllCandidates(body.from, body.to, body.when);

    const candidates = (tflResponse.journeys ?? []).map((j, i) => ({
      id: `j${i}`,
      legs: normaliseJourney(j),
      fareGBP: j.fare?.totalCost ? j.fare.totalCost / 100 : estimateFareFromLegs(j),
    }));

    if (candidates.length === 0) {
      return NextResponse.json({ routes: [], note: 'No journeys found' });
    }

    const scored = scoreRoutes(candidates, body);

    // Attach explanations (scoring is pure, explain needs the set)
    for (const route of scored) {
      const { whyThis, whyNot } = explain(route, scored);
      route.whyThis = whyThis;
      route.whyNot = whyNot;
    }

    cache.set(key, { at: Date.now(), routes: scored });
    return NextResponse.json({ routes: scored, cached: false });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ error: msg }, { status: 502 });
  }
}

/**
 * Fallback fare estimate when TfL doesn't return one.
 * Rough 2026 TfL peak-equivalent figures — refine once you start using the app.
 */
function estimateFareFromLegs(j: { legs?: Array<{ mode?: { name?: string } }> }): number {
  const legs = j.legs ?? [];
  const modes = new Set(legs.map((l) => l.mode?.name?.toLowerCase() ?? ''));
  let fare = 0;
  if (modes.has('bus')) fare += 1.75;
  if ([...modes].some((m) => m.includes('tube') || m.includes('elizabeth') || m.includes('dlr') || m.includes('overground'))) {
    fare += 2.90;
  }
  if ([...modes].some((m) => m.includes('rail'))) fare += 5.00;
  return fare;
}
