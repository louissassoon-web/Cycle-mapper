'use client';

import { useState } from 'react';
import { PlanForm } from '@/components/PlanForm';
import { RouteCard } from '@/components/RouteCard';
import type { PlanRequest, ScoredRoute } from '@/lib/types';

export default function Page() {
  const [loading, setLoading] = useState(false);
  const [routes, setRoutes] = useState<ScoredRoute[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handlePlan(req: PlanRequest) {
    setLoading(true);
    setError(null);
    setRoutes(null);
    try {
      const res = await fetch('/api/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({ error: 'Request failed' }));
        throw new Error(body.error ?? `HTTP ${res.status}`);
      }
      const data = await res.json();
      setRoutes(data.routes ?? []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  }

  // Order routes by label priority so balanced shows first
  const orderedRoutes = routes ? orderRoutes(routes) : null;

  return (
    <main className="min-h-screen mx-auto max-w-xl px-4 pt-6 pb-16">
      <header className="mb-6">
        <div className="flex items-baseline gap-2">
          <h1 className="font-display text-2xl font-semibold leading-tight">
            Brompton London
          </h1>
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted">
            mixed-mode planner
          </span>
        </div>
        <p className="text-sm text-muted mt-1">
          Routes that know when to ride and when to fold.
        </p>
      </header>

      <PlanForm onPlan={handlePlan} loading={loading} />

      {error && (
        <div className="mt-4 border border-ink bg-mode-tube/10 px-4 py-3 text-sm">
          <span className="font-mono text-[10px] uppercase tracking-wider text-mode-tube">Error</span>
          <p className="mt-1">{error}</p>
        </div>
      )}

      {loading && (
        <div className="mt-6 space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="border border-ink bg-paper h-48 animate-pulse opacity-40" />
          ))}
        </div>
      )}

      {orderedRoutes && orderedRoutes.length === 0 && !loading && (
        <div className="mt-6 border border-ink bg-paper p-6 text-center">
          <p className="text-sm">No routes found. Try loosening the constraints.</p>
        </div>
      )}

      {orderedRoutes && orderedRoutes.length > 0 && (
        <div className="mt-6 space-y-3">
          {orderedRoutes.map((route, i) => (
            <RouteCard key={route.id} route={route} rank={i + 1} />
          ))}
        </div>
      )}

      <footer className="mt-12 text-[10px] font-mono text-muted tabular">
        Data: TfL Unified API · Scoring is opinionated
      </footer>
    </main>
  );
}

const labelPriority = ['balanced', 'fastest', 'cheapest', 'least-hassle'];

function orderRoutes(routes: ScoredRoute[]): ScoredRoute[] {
  return [...routes].sort((a, b) => {
    const aP = Math.min(...a.labels.map((l) => labelPriority.indexOf(l)));
    const bP = Math.min(...b.labels.map((l) => labelPriority.indexOf(l)));
    return aP - bP;
  });
}
