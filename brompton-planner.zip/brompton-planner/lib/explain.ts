// Build "why this" / "why not" strings from scoring signals.
// No LLM — template-driven so it's fast, free, and predictable.

import type { ScoredRoute } from './types';

export function explain(route: ScoredRoute, all: ScoredRoute[]): { whyThis: string; whyNot: string } {
  const { totals, labels } = route;

  const reasons: string[] = [];

  if (labels.includes('fastest')) {
    reasons.push(`Fastest option at ${totals.durationMinutes} min`);
  }
  if (labels.includes('cheapest')) {
    reasons.push(`Cheapest at £${totals.fareGBP.toFixed(2)}`);
  }
  if (totals.changes === 0) reasons.push('no interchanges');
  else if (totals.changes === 1) reasons.push('only one change');

  if (totals.folds === 0) reasons.push('no folding required');
  else if (totals.folds === 1) reasons.push('single fold point');

  if (totals.cycleMinutes >= 10 && totals.cycleMinutes <= 25) {
    reasons.push('sensible amount of cycling');
  }

  // "Why not" — surface the biggest weakness
  const drawbacks: string[] = [];
  if (totals.folds >= 3) drawbacks.push(`requires folding ${totals.folds} times`);
  if (totals.changes >= 3) drawbacks.push(`${totals.changes} changes`);
  if (totals.walkCarryMinutes >= 8) drawbacks.push(`${Math.round(totals.walkCarryMinutes)} min carrying the folded bike`);

  // Compare to best alternatives
  const fastest = all.reduce((a, b) => a.totals.durationMinutes <= b.totals.durationMinutes ? a : b);
  const cheapest = all.reduce((a, b) => a.totals.fareGBP <= b.totals.fareGBP ? a : b);

  if (route !== fastest) {
    const diff = totals.durationMinutes - fastest.totals.durationMinutes;
    if (diff >= 5) drawbacks.push(`${diff} min slower than the fastest`);
  }
  if (route !== cheapest) {
    const diff = totals.fareGBP - cheapest.totals.fareGBP;
    if (diff >= 2) drawbacks.push(`£${diff.toFixed(2)} more than the cheapest`);
  }

  const whyThis = reasons.length > 0
    ? capitalise(reasons.slice(0, 2).join('; '))
    : 'A reasonable balance across the board';

  const whyNot = drawbacks.length > 0
    ? capitalise(drawbacks[0])
    : 'No major drawbacks';

  return { whyThis, whyNot };
}

function capitalise(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
