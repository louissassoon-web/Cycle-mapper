// Scoring: turn a set of candidate journeys into ranked, labelled routes.
// This is the product's core IP. Keep it pure (no I/O) so it's unit-testable.

import type {
  FoldEvent,
  Leg,
  PlanRequest,
  RouteLabel,
  RouteScores,
  RouteTotals,
  ScoredRoute,
  StationMeta,
} from './types';
import { computeFoldEvents, countFolds } from './folding';
import stationsJson from '../data/stations.json';

const STATIONS = stationsJson as StationMeta[];

function findStation(naptanId?: string): StationMeta | undefined {
  if (!naptanId) return undefined;
  return STATIONS.find((s) => s.naptanId === naptanId);
}

/** Compute raw totals — pure aggregation, no scoring yet. */
export function computeTotals(legs: Leg[], folds: number, fareGBP: number): RouteTotals {
  let cycleMinutes = 0;
  let transitMinutes = 0;
  let walkCarryMinutes = 0;
  let changes = 0;

  let prevMode: Leg['mode'] | undefined;
  for (const leg of legs) {
    if (leg.mode === 'cycle') cycleMinutes += leg.durationMinutes;
    else if (leg.mode === 'walk') {
      if (leg.bikeState === 'folded-carry') walkCarryMinutes += leg.durationMinutes;
    } else {
      transitMinutes += leg.durationMinutes;
      // Count a change when we switch between different transit modes/lines,
      // excluding the initial entry onto public transport.
      if (prevMode && prevMode !== 'walk' && prevMode !== 'cycle' && prevMode !== leg.mode) {
        changes += 1;
      }
    }
    prevMode = leg.mode;
  }

  const durationMinutes = legs.reduce((sum, l) => sum + l.durationMinutes, 0);

  return {
    durationMinutes,
    fareGBP,
    cycleMinutes,
    transitMinutes,
    walkCarryMinutes,
    changes,
    folds,
  };
}

/** Raw hassle score: sum of penalties. Lower = less hassle. */
export function hassleRaw(legs: Leg[], folds: number, totals: RouteTotals): number {
  let penalty = 0;

  penalty += totals.changes * 1.0;
  penalty += folds * 1.5;

  // Awkward interchange lookup
  for (const leg of legs) {
    const station = findStation(leg.from.naptanId) ?? findStation(leg.to.naptanId);
    if (station?.awkwardForFoldedBike) penalty += 2.0;
  }

  // Long folded-carry walking segments
  for (const leg of legs) {
    if (leg.mode === 'walk' && leg.bikeState === 'folded-carry' && leg.durationMinutes > 5) {
      penalty += 0.5 * (leg.durationMinutes - 5);
    }
  }

  // Peak buses with folded bike
  for (const leg of legs) {
    if (leg.mode === 'bus' && leg.isPeak) penalty += 0.3;
  }

  return penalty;
}

interface Normaliser {
  min: number;
  max: number;
}

/** Returns a normalise-to-0..1 function. Higher raw = lower score (since lower is better for time/cost/hassle/carry). */
function makeNormaliser(values: number[]): (v: number) => number {
  const min = Math.min(...values);
  const max = Math.max(...values);
  if (max === min) return () => 1;
  return (v: number) => 1 - (v - min) / (max - min);
}

interface CandidateInput {
  id: string;
  legs: Leg[];
  fareGBP: number;
}

export function scoreRoutes(candidates: CandidateInput[], req: PlanRequest): ScoredRoute[] {
  // Hard filters first — remove journeys violating user constraints.
  const filtered = candidates.filter((c) => {
    // Max cycle time per leg
    for (const leg of c.legs) {
      if (leg.mode === 'cycle' && leg.durationMinutes > req.maxCycleMinutesPerLeg) return false;
    }
    // Step-free — very conservative; flag and filter if any station is non-step-free
    if (req.stepFreeOnly) {
      for (const leg of c.legs) {
        const s = findStation(leg.from.naptanId) ?? findStation(leg.to.naptanId);
        if (s && s.stepFree === 'none') return false;
      }
    }
    return true;
  });

  if (filtered.length === 0) return [];

  // Compute per-candidate fold events + totals + raw hassle.
  const enriched = filtered.map((c) => {
    const foldEvents = computeFoldEvents(c.legs);
    const folds = countFolds(foldEvents);
    const totals = computeTotals(c.legs, folds, c.fareGBP);
    const hassle = hassleRaw(c.legs, folds, totals);
    return { ...c, foldEvents, totals, hassle };
  });

  // Normalise across candidates.
  const nTime = makeNormaliser(enriched.map((e) => e.totals.durationMinutes));
  const nCost = makeNormaliser(enriched.map((e) => e.totals.fareGBP));
  const nHassle = makeNormaliser(enriched.map((e) => e.hassle));
  const nCarry = makeNormaliser(enriched.map((e) => e.totals.walkCarryMinutes));

  // Weights — if user submits zeros, fall back to defaults.
  const w = req.weights;
  const sum = w.time + w.cost + w.hassle + w.carry || 1;
  const wT = w.time / sum;
  const wC = w.cost / sum;
  const wH = w.hassle / sum;
  const wK = w.carry / sum;

  // Luggage multiplier: carrying penalty is worse with extra bags.
  const carryMult = req.hasExtraLuggage ? 1.5 : 1.0;

  const scored: ScoredRoute[] = enriched.map((e) => {
    const time = nTime(e.totals.durationMinutes);
    const cost = nCost(e.totals.fareGBP);
    const hassle = nHassle(e.hassle);
    const carry = nCarry(e.totals.walkCarryMinutes * carryMult);

    let composite = wT * time + wC * cost + wH * hassle + wK * carry;

    // Directness bonus: 0 or 1 interchanges
    if (e.totals.changes <= 1) composite *= 1.05;

    const scores: RouteScores = { time, cost, hassle, carry, composite };

    return {
      id: e.id,
      legs: e.legs,
      foldEvents: e.foldEvents,
      totals: e.totals,
      scores,
      labels: [],
      whyThis: '',
      whyNot: '',
    };
  });

  // Value-trap: if A is <10% faster than B but >50% more expensive, down-weight A.
  for (const a of scored) {
    for (const b of scored) {
      if (a === b) continue;
      const timeAdvantage = (b.totals.durationMinutes - a.totals.durationMinutes) / b.totals.durationMinutes;
      const costPenalty = (a.totals.fareGBP - b.totals.fareGBP) / (b.totals.fareGBP || 1);
      if (timeAdvantage > 0 && timeAdvantage < 0.10 && costPenalty > 0.50) {
        a.scores.composite *= 0.85;
      }
    }
  }

  // Assign labels
  const byTime = [...scored].sort((a, b) => a.totals.durationMinutes - b.totals.durationMinutes);
  const byCost = [...scored].sort((a, b) => a.totals.fareGBP - b.totals.fareGBP);
  const byComposite = [...scored].sort((a, b) => b.scores.composite - a.scores.composite);
  const byHassle = [...scored].sort((a, b) => b.scores.hassle - a.scores.hassle);

  assignLabel(byTime[0], 'fastest');
  assignLabel(byCost[0], 'cheapest');
  assignLabel(byComposite[0], 'balanced');

  // Only add "least-hassle" label if it's a genuinely different route
  if (byHassle[0] && !byHassle[0].labels.includes('balanced')) {
    assignLabel(byHassle[0], 'least-hassle');
  }

  return scored.filter((r) => r.labels.length > 0);
}

function assignLabel(r: ScoredRoute | undefined, label: RouteLabel): void {
  if (r && !r.labels.includes(label)) r.labels.push(label);
}
