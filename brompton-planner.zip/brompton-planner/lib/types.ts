// Shared types for the Brompton journey planner.
// Keep this file as the single source of truth for data shapes.

export type Mode =
  | 'walk'
  | 'cycle'
  | 'tube'
  | 'bus'
  | 'rail'
  | 'overground'
  | 'elizabeth-line'
  | 'dlr';

export type BikeState =
  | 'deployed'       // being ridden
  | 'folded-carry'   // folded, being carried (walking with it)
  | 'folded-luggage';// folded, on transit (counts as luggage)

export interface PlanRequest {
  from: string;
  to: string;
  when: { mode: 'depart' | 'arrive'; iso: string };
  weights: {
    time: number;    // 0..1, should sum to 1 with others
    cost: number;
    hassle: number;
    carry: number;
  };
  maxCycleMinutesPerLeg: number;
  hasExtraLuggage: boolean;
  stepFreeOnly: boolean;
}

export interface Place {
  name: string;
  naptanId?: string;
  lat?: number;
  lon?: number;
}

export interface Leg {
  mode: Mode;
  from: Place;
  to: Place;
  durationMinutes: number;
  distanceMetres?: number;
  lineName?: string;
  bikeState: BikeState;
  instructions?: string[];
  // Flags set by enrichment step
  interchangeIsAwkward?: boolean;
  isPeak?: boolean;
}

export interface FoldEvent {
  at: string;
  action: 'fold' | 'unfold';
  afterLegIndex: number;
}

export interface RouteTotals {
  durationMinutes: number;
  fareGBP: number;
  cycleMinutes: number;
  transitMinutes: number;
  walkCarryMinutes: number;
  changes: number;
  folds: number;
}

export interface RouteScores {
  time: number;      // 0..1, higher = better
  cost: number;
  hassle: number;    // 0..1, higher = LESS hassle
  carry: number;     // 0..1, higher = LESS carrying
  composite: number;
}

export type RouteLabel = 'fastest' | 'cheapest' | 'balanced' | 'least-hassle';

export interface ScoredRoute {
  id: string;
  legs: Leg[];
  foldEvents: FoldEvent[];
  totals: RouteTotals;
  scores: RouteScores;
  labels: RouteLabel[];
  whyThis: string;
  whyNot: string;
}

export interface StationMeta {
  naptanId: string;
  name: string;
  stepFree: 'none' | 'platform' | 'street';
  awkwardForFoldedBike: boolean;
  notes?: string;
}

// TfL response types — hand-written subset of what we actually use.
// Generated from a real TfL response; expand as needed, don't over-type.
export interface TflJourneyResponse {
  journeys: TflJourney[];
}

export interface TflJourney {
  duration: number;
  startDateTime: string;
  arrivalDateTime: string;
  fare?: { totalCost: number }; // pence
  legs: TflLeg[];
}

export interface TflLeg {
  duration: number; // minutes
  instruction?: { summary?: string; detailed?: string };
  departurePoint?: { commonName?: string; naptanId?: string; lat?: number; lon?: number };
  arrivalPoint?: { commonName?: string; naptanId?: string; lat?: number; lon?: number };
  mode?: { id?: string; name?: string; type?: string };
  routeOptions?: Array<{ name?: string; lineIdentifier?: { name?: string } }>;
  distance?: number; // metres
  isDisrupted?: boolean;
}
