// Thin TfL Unified API client.
// Docs: https://api.tfl.gov.uk/
// App key is optional for low volumes but recommended.

import type { TflJourneyResponse } from './types';

const TFL_BASE = 'https://api.tfl.gov.uk';

function appKey(): string | undefined {
  return process.env.TFL_APP_KEY;
}

function withKey(url: URL): URL {
  const key = appKey();
  if (key) url.searchParams.set('app_key', key);
  return url;
}

export interface JourneyQuery {
  from: string;
  to: string;
  when?: { mode: 'depart' | 'arrive'; iso: string };
  mode?: string[];       // e.g. ['cycle','tube','bus','national-rail','elizabeth-line','overground','dlr','walking']
  bikeProfile?: 'flat' | 'fast' | 'quiet';
}

/**
 * Fetch candidate journeys from TfL.
 * We typically call this 2–3 times per plan request with different mode sets
 * and merge results upstream.
 */
export async function fetchJourneys(q: JourneyQuery): Promise<TflJourneyResponse> {
  const from = encodeURIComponent(q.from);
  const to = encodeURIComponent(q.to);
  const url = new URL(`${TFL_BASE}/Journey/JourneyResults/${from}/to/${to}`);

  if (q.when) {
    const dt = new Date(q.when.iso);
    const date = dt.toISOString().slice(0, 10).replace(/-/g, '');
    const time = dt.toISOString().slice(11, 16).replace(':', '');
    url.searchParams.set('date', date);
    url.searchParams.set('time', time);
    url.searchParams.set('timeIs', q.when.mode === 'arrive' ? 'Arriving' : 'Departing');
  }
  if (q.mode?.length) url.searchParams.set('mode', q.mode.join(','));
  if (q.bikeProfile) url.searchParams.set('bikeProfile', q.bikeProfile);

  const res = await fetch(withKey(url).toString(), {
    // Cache at the edge for a minute — scores are stable at that timescale.
    next: { revalidate: 60 },
  });

  if (!res.ok) {
    throw new Error(`TfL journey request failed: ${res.status} ${res.statusText}`);
  }
  return res.json() as Promise<TflJourneyResponse>;
}

/** Fetch all three variants in parallel and flatten. */
export async function fetchAllCandidates(
  from: string,
  to: string,
  when?: JourneyQuery['when']
): Promise<TflJourneyResponse> {
  const transitModes = ['tube', 'bus', 'national-rail', 'elizabeth-line', 'overground', 'dlr', 'walking'];
  const [cycleMixed, transitOnly, cycleFlat] = await Promise.all([
    fetchJourneys({ from, to, when, mode: ['cycle', ...transitModes] }),
    fetchJourneys({ from, to, when, mode: transitModes }),
    fetchJourneys({ from, to, when, mode: ['cycle', ...transitModes], bikeProfile: 'flat' }),
  ]);
  return {
    journeys: [
      ...(cycleMixed.journeys ?? []),
      ...(transitOnly.journeys ?? []),
      ...(cycleFlat.journeys ?? []),
    ],
  };
}
