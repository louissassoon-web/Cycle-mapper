// Convert raw TfL journeys to our internal Leg[] with Brompton bike state.
// The key insight: bike state is determined by the *sequence* of legs,
// not any individual leg, so we need to look at neighbours.

import type { Leg, Mode, TflJourney, TflLeg } from './types';

function mapMode(tfl: TflLeg): Mode {
  const name = (tfl.mode?.name ?? tfl.mode?.id ?? '').toLowerCase();
  if (name.includes('walk')) return 'walk';
  if (name.includes('cycle') || name.includes('bike')) return 'cycle';
  if (name.includes('elizabeth')) return 'elizabeth-line';
  if (name.includes('overground')) return 'overground';
  if (name.includes('dlr')) return 'dlr';
  if (name.includes('bus')) return 'bus';
  if (name.includes('tube') || name.includes('underground')) return 'tube';
  if (name.includes('rail') || name.includes('train')) return 'rail';
  // Safer to assume walking than to invent a mode we don't handle.
  return 'walk';
}

function lineNameOf(tfl: TflLeg): string | undefined {
  const ro = tfl.routeOptions?.[0];
  return ro?.name ?? ro?.lineIdentifier?.name;
}

/**
 * Determine bike state for each leg based on position in the journey.
 *   - cycle leg          → deployed
 *   - transit leg        → folded-luggage
 *   - walk leg at start  → deployed (wheeling next to you) IF next leg is cycle
 *                        → folded-carry otherwise
 *   - walk leg at end    → deployed IF previous leg was cycle
 *                        → folded-carry otherwise
 *   - walk leg in middle → folded-carry between transit legs
 *                        → deployed if sandwiched between cycle legs
 *
 * We take the pragmatic view that the user starts with the bike deployed or
 * folded based on the first leg's context and makes it match.
 */
export function normaliseJourney(j: TflJourney): Leg[] {
  const raw = (j.legs ?? []).map((l, idx) => {
    const mode = mapMode(l);
    return {
      raw: l,
      mode,
      durationMinutes: l.duration,
      distanceMetres: l.distance,
      lineName: lineNameOf(l),
      from: {
        name: l.departurePoint?.commonName ?? 'Start',
        naptanId: l.departurePoint?.naptanId,
        lat: l.departurePoint?.lat,
        lon: l.departurePoint?.lon,
      },
      to: {
        name: l.arrivalPoint?.commonName ?? 'End',
        naptanId: l.arrivalPoint?.naptanId,
        lat: l.arrivalPoint?.lat,
        lon: l.arrivalPoint?.lon,
      },
      idx,
    };
  });

  return raw.map((leg, i): Leg => {
    const prev = raw[i - 1];
    const next = raw[i + 1];
    let bikeState: Leg['bikeState'];

    if (leg.mode === 'cycle') {
      bikeState = 'deployed';
    } else if (leg.mode === 'walk') {
      const prevWasCycle = prev?.mode === 'cycle';
      const nextIsCycle = next?.mode === 'cycle';
      // If we're starting/ending a ride, the bike is deployed (being wheeled).
      // Otherwise it's folded and being carried.
      bikeState = prevWasCycle || nextIsCycle ? 'deployed' : 'folded-carry';
    } else {
      // Any transit mode: bike must be folded.
      bikeState = 'folded-luggage';
    }

    return {
      mode: leg.mode,
      from: leg.from,
      to: leg.to,
      durationMinutes: leg.durationMinutes,
      distanceMetres: leg.distanceMetres,
      lineName: leg.lineName,
      bikeState,
      isPeak: isPeakTime(new Date()),
    };
  });
}

function isPeakTime(d: Date): boolean {
  const day = d.getDay(); // 0 Sun ... 6 Sat
  if (day === 0 || day === 6) return false;
  const h = d.getHours();
  return (h >= 7 && h < 10) || (h >= 16 && h < 19);
}
