// Compute fold / unfold events between legs.
// A fold event happens when bike state transitions between deployed and folded.

import type { FoldEvent, Leg } from './types';

function isDeployed(state: Leg['bikeState']): boolean {
  return state === 'deployed';
}

export function computeFoldEvents(legs: Leg[]): FoldEvent[] {
  const events: FoldEvent[] = [];

  // Assume user starts with bike in whatever state the first leg implies.
  for (let i = 0; i < legs.length - 1; i++) {
    const curr = legs[i];
    const next = legs[i + 1];
    const currDeployed = isDeployed(curr.bikeState);
    const nextDeployed = isDeployed(next.bikeState);

    if (currDeployed && !nextDeployed) {
      events.push({
        at: curr.to.name,
        action: 'fold',
        afterLegIndex: i,
      });
    } else if (!currDeployed && nextDeployed) {
      events.push({
        at: curr.to.name,
        action: 'unfold',
        afterLegIndex: i,
      });
    }
  }

  return events;
}

export function countFolds(events: FoldEvent[]): number {
  return events.filter((e) => e.action === 'fold').length;
}
