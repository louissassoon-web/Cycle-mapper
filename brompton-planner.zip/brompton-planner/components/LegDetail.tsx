'use client';

import type { FoldEvent, Leg, Mode } from '@/lib/types';

const modeLabels: Record<Mode, string> = {
  tube: 'Tube',
  bus: 'Bus',
  rail: 'Rail',
  'elizabeth-line': 'Elizabeth line',
  overground: 'Overground',
  dlr: 'DLR',
  cycle: 'Ride',
  walk: 'Walk',
};

const bikeStateText: Record<Leg['bikeState'], string> = {
  deployed: 'bike ridden / wheeled',
  'folded-carry': 'bike folded, carried',
  'folded-luggage': 'bike folded, as luggage',
};

interface Props {
  legs: Leg[];
  foldEvents: FoldEvent[];
}

export function LegDetail({ legs, foldEvents }: Props) {
  const foldMap = new Map<number, FoldEvent>();
  foldEvents.forEach((f) => foldMap.set(f.afterLegIndex, f));

  return (
    <ol className="divide-y divide-rule/20">
      {legs.map((leg, i) => {
        const fold = foldMap.get(i);
        return (
          <li key={i}>
            <div className="px-4 py-3 grid grid-cols-[auto_1fr_auto] gap-x-3 items-baseline">
              <span className="font-mono text-[10px] uppercase tracking-wider text-muted tabular">
                {String(i + 1).padStart(2, '0')}
              </span>
              <div>
                <div className="text-sm">
                  <span className="font-medium">{modeLabels[leg.mode]}</span>
                  {leg.lineName && <span className="text-muted"> · {leg.lineName}</span>}
                </div>
                <div className="text-xs text-muted mt-0.5">
                  {leg.from.name} → {leg.to.name}
                </div>
                <div className="text-[10px] font-mono text-muted mt-1">
                  {bikeStateText[leg.bikeState]}
                </div>
              </div>
              <span className="font-mono text-xs tabular text-ink">
                {leg.durationMinutes} min
              </span>
            </div>
            {fold && i < legs.length - 1 && (
              <div className="bg-ink text-paper px-4 py-1.5 flex items-center gap-2 text-xs font-mono">
                <span className="text-base leading-none">
                  {fold.action === 'fold' ? '⊟' : '⊞'}
                </span>
                <span className="uppercase tracking-wider">
                  {fold.action} at {fold.at}
                </span>
              </div>
            )}
          </li>
        );
      })}
    </ol>
  );
}
