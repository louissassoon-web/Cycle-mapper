'use client';

import { useState } from 'react';
import type { ScoredRoute } from '@/lib/types';
import { LegStrip } from './LegStrip';
import { LegDetail } from './LegDetail';

const labelCopy: Record<string, { text: string; accent: string }> = {
  balanced: { text: 'Balanced', accent: 'bg-ink text-paper' },
  fastest: { text: 'Fastest', accent: 'bg-mode-tube text-paper' },
  cheapest: { text: 'Cheapest', accent: 'bg-mode-dlr text-paper' },
  'least-hassle': { text: 'Least hassle', accent: 'bg-mode-elizabeth text-paper' },
};

interface Props {
  route: ScoredRoute;
  rank: number;
}

export function RouteCard({ route, rank }: Props) {
  const [expanded, setExpanded] = useState(false);
  const { totals, labels, whyThis, whyNot, foldEvents, legs } = route;

  return (
    <article className="border border-ink bg-paper shadow-card">
      <header className="px-4 pt-3 pb-2">
        <div className="flex items-start justify-between gap-3">
          <div className="flex flex-wrap gap-1">
            {labels.map((l) => {
              const c = labelCopy[l];
              return (
                <span
                  key={l}
                  className={`${c.accent} text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5`}
                >
                  {c.text}
                </span>
              );
            })}
          </div>
          <span className="font-mono text-[10px] text-muted">#{rank}</span>
        </div>

        <div className="mt-3 flex items-baseline gap-4">
          <div>
            <div className="font-display text-4xl leading-none tabular">
              {totals.durationMinutes}
              <span className="text-base text-muted ml-1">min</span>
            </div>
          </div>
          <div>
            <div className="font-display text-2xl leading-none tabular text-ink">
              £{totals.fareGBP.toFixed(2)}
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 py-3">
        <LegStrip legs={legs} foldPoints={foldEvents} />
      </div>

      <div className="px-4 pb-3 space-y-1.5 text-sm">
        <p className="text-ink">
          <span className="font-mono text-[10px] uppercase text-muted mr-1.5">Why</span>
          {whyThis}
        </p>
        <p className="text-muted">
          <span className="font-mono text-[10px] uppercase text-muted mr-1.5">But</span>
          {whyNot}
        </p>
      </div>

      <div className="hairline mx-4" />

      <div className="px-4 py-2.5 flex items-center gap-4 text-[11px] font-mono text-muted tabular">
        <span>{totals.changes} chg</span>
        <span>{totals.folds} fold{totals.folds !== 1 ? 's' : ''}</span>
        <span>{totals.cycleMinutes}m ride</span>
        <span>{totals.walkCarryMinutes}m carry</span>
        <button
          type="button"
          onClick={() => setExpanded(!expanded)}
          className="ml-auto underline underline-offset-2 hover:no-underline"
          aria-expanded={expanded}
        >
          {expanded ? 'Hide detail' : 'Show detail'}
        </button>
      </div>

      {expanded && (
        <div className="border-t border-ink bg-paper">
          <LegDetail legs={legs} foldEvents={foldEvents} />
        </div>
      )}
    </article>
  );
}
