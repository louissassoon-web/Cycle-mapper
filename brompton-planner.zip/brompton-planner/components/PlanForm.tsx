'use client';

import { useState } from 'react';
import type { PlanRequest } from '@/lib/types';

interface Props {
  onPlan: (req: PlanRequest) => void;
  loading: boolean;
}

const defaultWeights = { time: 0.25, cost: 0.25, hassle: 0.35, carry: 0.15 };

export function PlanForm({ onPlan, loading }: Props) {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [whenMode, setWhenMode] = useState<'depart' | 'arrive'>('depart');
  const [whenTime, setWhenTime] = useState<string>('');
  const [weights, setWeights] = useState(defaultWeights);
  const [maxCycle, setMaxCycle] = useState(20);
  const [hasLuggage, setHasLuggage] = useState(false);
  const [stepFree, setStepFree] = useState(false);
  const [showOptions, setShowOptions] = useState(false);

  function handleSubmit() {
    if (!from.trim() || !to.trim()) return;
    const iso = whenTime ? new Date(whenTime).toISOString() : new Date().toISOString();
    onPlan({
      from: from.trim(),
      to: to.trim(),
      when: { mode: whenMode, iso },
      weights,
      maxCycleMinutesPerLeg: maxCycle,
      hasExtraLuggage: hasLuggage,
      stepFreeOnly: stepFree,
    });
  }

  function updateWeight(key: keyof typeof weights, value: number) {
    setWeights({ ...weights, [key]: value });
  }

  return (
    <section className="border border-ink bg-paper shadow-card">
      <div className="p-4 space-y-3">
        <label className="block">
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted">From</span>
          <input
            type="text"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            placeholder="Postcode, station, or place"
            className="mt-1 w-full border-b border-ink bg-transparent py-1.5 text-base focus:outline-none focus:border-b-2"
            autoComplete="off"
          />
        </label>
        <label className="block">
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted">To</span>
          <input
            type="text"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            placeholder="Postcode, station, or place"
            className="mt-1 w-full border-b border-ink bg-transparent py-1.5 text-base focus:outline-none focus:border-b-2"
            autoComplete="off"
          />
        </label>

        <div className="flex gap-2 pt-1">
          <button
            type="button"
            onClick={() => setWhenMode('depart')}
            className={`flex-1 py-1.5 text-xs font-mono uppercase tracking-wider border border-ink ${
              whenMode === 'depart' ? 'bg-ink text-paper' : 'bg-transparent text-ink'
            }`}
          >
            Depart at
          </button>
          <button
            type="button"
            onClick={() => setWhenMode('arrive')}
            className={`flex-1 py-1.5 text-xs font-mono uppercase tracking-wider border border-ink ${
              whenMode === 'arrive' ? 'bg-ink text-paper' : 'bg-transparent text-ink'
            }`}
          >
            Arrive by
          </button>
        </div>

        <input
          type="datetime-local"
          value={whenTime}
          onChange={(e) => setWhenTime(e.target.value)}
          className="w-full border border-ink bg-transparent px-2 py-1.5 text-sm font-mono tabular"
          placeholder="Now"
        />
        <p className="text-[10px] font-mono text-muted">Leave blank for 'now'</p>

        <button
          type="button"
          onClick={() => setShowOptions(!showOptions)}
          className="text-xs font-mono uppercase tracking-wider underline underline-offset-2"
          aria-expanded={showOptions}
        >
          {showOptions ? 'Hide options' : 'Show options'}
        </button>
      </div>

      {showOptions && (
        <div className="border-t border-ink p-4 space-y-4">
          <fieldset className="space-y-2">
            <legend className="font-mono text-[10px] uppercase tracking-wider text-muted mb-1">
              Priority weights
            </legend>
            <WeightSlider label="Time" value={weights.time} onChange={(v) => updateWeight('time', v)} />
            <WeightSlider label="Cost" value={weights.cost} onChange={(v) => updateWeight('cost', v)} />
            <WeightSlider label="Hassle" value={weights.hassle} onChange={(v) => updateWeight('hassle', v)} />
            <WeightSlider label="Carrying" value={weights.carry} onChange={(v) => updateWeight('carry', v)} />
          </fieldset>

          <label className="block">
            <span className="font-mono text-[10px] uppercase tracking-wider text-muted">
              Max cycling per leg: {maxCycle} min
            </span>
            <input
              type="range"
              min={5}
              max={45}
              step={5}
              value={maxCycle}
              onChange={(e) => setMaxCycle(Number(e.target.value))}
              className="mt-1 w-full accent-ink"
            />
          </label>

          <div className="flex gap-4">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={hasLuggage}
                onChange={(e) => setHasLuggage(e.target.checked)}
                className="accent-ink"
              />
              Extra luggage
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={stepFree}
                onChange={(e) => setStepFree(e.target.checked)}
                className="accent-ink"
              />
              Step-free only
            </label>
          </div>
        </div>
      )}

      <button
        type="button"
        onClick={handleSubmit}
        disabled={loading || !from || !to}
        className="w-full bg-ink text-paper py-3 font-mono text-xs uppercase tracking-[0.2em] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-rule transition-colors"
      >
        {loading ? 'Planning…' : 'Plan journey →'}
      </button>
    </section>
  );
}

function WeightSlider({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <label className="block">
      <div className="flex justify-between items-baseline">
        <span className="text-xs">{label}</span>
        <span className="font-mono text-[10px] text-muted tabular">{Math.round(value * 100)}%</span>
      </div>
      <input
        type="range"
        min={0}
        max={1}
        step={0.05}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-ink"
      />
    </label>
  );
}
