'use client';

import type { Leg, Mode } from '@/lib/types';

const modeColors: Record<Mode, string> = {
  tube: 'bg-mode-tube',
  bus: 'bg-mode-bus',
  rail: 'bg-mode-rail',
  'elizabeth-line': 'bg-mode-elizabeth',
  overground: 'bg-mode-overground',
  dlr: 'bg-mode-dlr',
  cycle: 'bg-ink',
  walk: 'bg-mode-walk',
};

const modeLabels: Record<Mode, string> = {
  tube: 'Tube',
  bus: 'Bus',
  rail: 'Rail',
  'elizabeth-line': 'Lizzy',
  overground: 'Ogr',
  dlr: 'DLR',
  cycle: 'Ride',
  walk: 'Walk',
};

// Unicode glyphs for modes — small, text-friendly, don't need icon library
const modeGlyph: Record<Mode, string> = {
  tube: '◉',
  bus: '▭',
  rail: '▤',
  'elizabeth-line': '⬡',
  overground: '◇',
  dlr: '◆',
  cycle: '⌾',
  walk: '•',
};

interface Props {
  legs: Leg[];
  foldPoints: Array<{ afterLegIndex: number; action: 'fold' | 'unfold' }>;
}

/**
 * Horizontal strip showing the journey as a sequence of mode blocks,
 * with fold/unfold markers between them. Widths are proportional to
 * leg duration so the visual scanning matches actual time spent.
 */
export function LegStrip({ legs, foldPoints }: Props) {
  const total = legs.reduce((sum, l) => sum + l.durationMinutes, 0) || 1;
  const foldMap = new Map<number, 'fold' | 'unfold'>();
  foldPoints.forEach((fp) => foldMap.set(fp.afterLegIndex, fp.action));

  return (
    <div className="w-full">
      <div className="flex items-stretch gap-[2px] h-8" role="list" aria-label="Journey legs">
        {legs.map((leg, i) => {
          const width = Math.max(4, (leg.durationMinutes / total) * 100);
          const fold = foldMap.get(i);
          return (
            <div key={i} className="flex items-stretch" style={{ width: `${width}%` }}>
              <div
                className={`${modeColors[leg.mode]} flex items-center justify-center px-1.5 text-[10px] font-mono text-paper flex-1 min-w-0`}
                role="listitem"
                title={`${modeLabels[leg.mode]}: ${leg.durationMinutes} min${leg.lineName ? ` (${leg.lineName})` : ''}`}
              >
                <span className="truncate">
                  {modeGlyph[leg.mode]}
                  <span className="ml-1">{leg.durationMinutes}</span>
                </span>
              </div>
              {fold && i < legs.length - 1 && (
                <div
                  className="flex items-center justify-center px-0.5 bg-paper border-y border-ink"
                  title={fold === 'fold' ? 'Fold the bike here' : 'Unfold the bike here'}
                  aria-label={fold === 'fold' ? 'Fold point' : 'Unfold point'}
                >
                  <span className="text-[10px] font-mono text-ink">
                    {fold === 'fold' ? '⊟' : '⊞'}
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div className="flex gap-1.5 mt-1.5 flex-wrap">
        {uniqueLines(legs).map((line, i) => (
          <span key={i} className="text-[10px] font-mono text-muted">{line}</span>
        ))}
      </div>
    </div>
  );
}

function uniqueLines(legs: Leg[]): string[] {
  const names: string[] = [];
  for (const leg of legs) {
    const label = leg.lineName ?? modeLabels[leg.mode];
    if (!names.includes(label)) names.push(label);
  }
  return names;
}
